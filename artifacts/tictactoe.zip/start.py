import json
import board

def entrypoint(event, context):
    initBoard = board.display_board(['#'])
    return {
        "statusCode": 200,
        "body": json.dumps(board.json_board(initBoard))
    }